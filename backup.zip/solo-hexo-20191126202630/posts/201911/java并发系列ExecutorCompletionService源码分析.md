title: 【java并发系列】ExecutorCompletionService源码分析
date: '2019-11-24 03:36:56'
updated: '2019-11-24 03:48:07'
tags: [java, 并发]
permalink: /articles/2019/11/24/1574537816768.html
---
![](https://img.hacpai.com/bing/20190416.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


**ExecutorCompletionService 主要用于解决在有一组异步任务提交的情况下，各个任务执行的耗时情况不一且相互独立，任何一个任务执行完成就可以继续跟这个任务相关的其他逻辑的场景。**

---
## 基本介绍
首先，我们看下 ExecutorCompletionService 的继承关系：
![屏幕快照 20191124 上午 2.03.51.png](https://img.hacpai.com/file/2019/11/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A720191124%E4%B8%8A%E5%8D%882.03.51-9a08b661.png)
实现了 CompletionService 接口，相对比较简单。
接下来主要分析下 ExecutorCompletionService 如何实现在一组任务提交之后，能够及时的拿到执行完成的任务结果。

## 实例分析

```
public class ExecutorCompletionServiceTest {
    private final static Executor executor = Executors.newFixedThreadPool(5);
    public static final int TASK_NUM = 5;
    private static final AtomicInteger atomicInteger = new AtomicInteger();

    public static void main(String[] args) throws Exception{
        ExecutorCompletionServiceTest test = new ExecutorCompletionServiceTest();
        // 1.构造ExecutorCompletionService
        ExecutorCompletionService<String> executorCompletionService = new ExecutorCompletionService<>(ExecutorCompletionServiceTest.executor);
        // 2.提交任务
        test.submitTask(executorCompletionService);
        // 3.获取任务结果
        for (int i = 0; i < TASK_NUM; i++) {
            Future<String> future = executorCompletionService.take();
            System.out.println(future.get());
        }
    }

    private void submitTask(ExecutorCompletionService<String> executorCompletionService) {
        for (int i = 0; i < TASK_NUM; i++) {
            // submit
            executorCompletionService.submit(new Tasker());
        }
    }

    class Tasker implements Callable<String> {

        @Override
        public String call() throws Exception {
            int sleepSec = new Random().nextInt(4) + 1;
            String str = Thread.currentThread().getName() + " ,我的下标为：" + atomicInteger.incrementAndGet() + " ,我睡了：" + sleepSec;
            TimeUnit.SECONDS.sleep(sleepSec);
            return str;
        }
    }
}
```

第一步，构建 ExecutorCompletionService，调用构造函数`ExecutorCompletionService(Executor executor)`，传递一个线程池进去，看到这里也能大概理解一些 ExecutorCompletionService 实现的形式了，提交给他的任务其实是交给了这里的 Executor 线程池来执行。继续看在构造函数里面还初始化了一个阻塞队列 LinkedBlockingQueue，这里我们先不说这个阻塞队列的作用，后面会介绍，继续往下看。
```
    public ExecutorCompletionService(Executor executor) {
        if (executor == null)
            throw new NullPointerException();
        this.executor = executor;
        this.aes = (executor instanceof AbstractExecutorService) ?
            (AbstractExecutorService) executor : null;
        this.completionQueue = new LinkedBlockingQueue<Future<V>>();
    }
```

第二步，提交任务，查看 submit 方法，源码如下：

```
    public Future<V> submit(Callable<V> task) {
        if (task == null) throw new NullPointerException();
        RunnableFuture<V> f = newTaskFor(task);
        executor.execute(new QueueingFuture(f));
        return f;
    }
```

调用 newTaskFor 方法，将传递进来的任务包装为 FutureTask;

```
    private RunnableFuture<V> newTaskFor(Callable<V> task) {
        if (aes == null)
            return new FutureTask<V>(task);
        else
            return aes.newTaskFor(task);
    }
```

接着利用 FutureTask 构建 ExecutorCompletionService 的内部类 QueueingFuture，重点看下这个内部类 QueueingFuture：

```
    private class QueueingFuture extends FutureTask<Void> {
        QueueingFuture(RunnableFuture<V> task) {
            super(task, null);
            this.task = task;
        }
        protected void done() { completionQueue.add(task); }
        private final Future<V> task;
    }
```

这个内部类继承了 FutureTask，重点是重写了 FutureTask 的 done()方法，将任务放到队列 completionQueue 里面去，看到这里也就知道了在构造函数中初始化的阻塞队列用处了，他就是用来存放提交的各个任务在执行完成后的结果的。那么为什么重写这个 done()方法就能达到这个效果呢？我们再看下 FutureTask 中的任务执行逻辑源码：

```
    public void run() {
        if (state != NEW ||
            !UNSAFE.compareAndSwapObject(this, runnerOffset,
                                         null, Thread.currentThread()))
            return;
        try {
            Callable<V> c = callable;
            if (c != null && state == NEW) {
                V result;
                boolean ran;
                try {
                    result = c.call();
                    ran = true;
                } catch (Throwable ex) {
                    result = null;
                    ran = false;
                    setException(ex);
                }
                if (ran)
		   // 在任务执行完成后调用这个set方法
                    set(result);
            }
        } finally {
            // runner must be non-null until state is settled to
            // prevent concurrent calls to run()
            runner = null;
            // state must be re-read after nulling runner to prevent
            // leaked interrupts
            int s = state;
            if (s >= INTERRUPTING)
                handlePossibleCancellationInterrupt(s);
        }
    }
```

这里我们关注在任务执行完成后调用的这个 set 方法，接着跟进去：

```
    protected void set(V v) {
        if (UNSAFE.compareAndSwapInt(this, stateOffset, NEW, COMPLETING)) {
            outcome = v;
            UNSAFE.putOrderedInt(this, stateOffset, NORMAL); // final state
            finishCompletion();
        }
    }
```

set 方法里面执行了一个内部方法 finishCompletion()，我们再进去看一下：

```
    /**
     * Removes and signals all waiting threads, invokes done(), and
     * nulls out callable.
     */
    private void finishCompletion() {
        // assert state > COMPLETING;
        for (WaitNode q; (q = waiters) != null;) {
            if (UNSAFE.compareAndSwapObject(this, waitersOffset, q, null)) {
                for (;;) {
                    Thread t = q.thread;
                    if (t != null) {
                        q.thread = null;
                        LockSupport.unpark(t);
                    }
                    WaitNode next = q.next;
                    if (next == null)
                        break;
                    q.next = null; // unlink to help gc
                    q = next;
                }
                break;
            }
        }
        // 这个就是我们要找的方法
        done();

        callable = null;        // to reduce footprint
    }
```

看到这里谜底也就解开了，在任务执行完成的逻辑最后它会调用一个内部方法 done()，这个方法在 FutureTask 源码中是个抽象方法，而在ExecutorCompletionService 提交任务时构建的内部类 QueueingFuture 中重写了这个done()方法，重写的逻辑是将任务结果存放到队列 completionQueue 中，那么也就说任务在执行完成后，通过调用这个重写的 done()方法，将执行的结果放到了队列中。
接着，第三步就比较简单了，先调用 ExecutorCompletionService 的 take()，我们看下 take()方法的实现：

```
    public Future<V> take() throws InterruptedException {
        return completionQueue.take();
    }
```

这里 ExecutorCompletionService 将 take()方法委托给了队列 completionQueue，我们知道 LinkedBlockingQueue 队列是个阻塞队列，在调用 take()方法时候会阻塞并等到队列里面有结果为止，这样也就保证了在其中某个任务执行完成之后，能够及时拿到其结果。
最后，通过 Future 的 get()方法获取任务的最终结果。

## 小结

自此，对 ExecutorCompletionService 的应用场景和源码做了基本的分析，ExecutorCompletionService 利用了线程池 Executor 和阻塞队列 LinkedBlockingQueue 完美的实现了我们在提交一批独立的任务之后，能够在某一个任务执行完成就能及时的获得结果并继续下面要做的事情。
