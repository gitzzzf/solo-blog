title: java利用idea在测试环境远程debug二三事
date: '2019-11-15 21:49:49'
updated: '2019-11-16 00:19:00'
tags: [java, debug, idea]
permalink: /articles/2019/11/15/1573825789298.html
---
![](https://img.hacpai.com/bing/20171210.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 一、问题描述
测试环境调试的过程中，大家是否是通过添加debug日志来追查数据的变化呢，但时常又苦恼不能跟踪到详细的数据？或者在本地起服务哼哧哼哧半天，再去进行本地调用的呢？今天这里介绍利用idea在测试环境中远程debug的一个小技巧，抛砖引玉，大家有更好的方式可以在评论中交流哈~

### 二、小技巧介绍
#### 2.1 小技巧介绍

话不多说，直接上菜。
首先，这里以基于docker的测试环境为例，使用docker compose管理容器，其配置文件一般位于测试环境的目录"/你的目录/compose"下面，进入到对应的配置里面，编辑compose.yml配置文件（这里目录和文件名大家可能各不相同）: 

```
vim /你的目录/compose.yml
```

以其中某一个微服务为例，观察到内容如下：
![屏幕快照20191115下午9.53.03.png](https://img.hacpai.com/file/2019/11/屏幕快照20191115下午9.53.03-3f4d9caa.png)


先说操作：
第一步，配置好红色标号①，除了address端口地址需要配置外，其他使用默认配置即可。
```
agentlib:jdwp=transport=dt_socket,address=21993,server=y,suspend=n
```


然后再将docker容器端口映射出来，见红色标号②。

第二步，打开idea中对应工程，做如下设置：
![屏幕快照20191115下午9.17.09.png](https://img.hacpai.com/file/2019/11/屏幕快照20191115下午9.17.09-7fabd44f.png)

点击红色序号①处配置，调出run/debug configuations页面，点击红色序号②，选择remote，如上图，在红色序号③处填上对应的测试环境的host以及我们在第一步中映射出来的端口，这里的图中host对应的就是我们的测试环境，端口就是我们从容器中端口21993映射出来的宿主端口号20993，这样配置已经完成。

第三步，配置完成之后，点击**debug**按钮，idea中出现如下界面“connected to the target VM....”，即表示debug连接成功。如下图：
![WechatIMG2.jpeg](https://img.hacpai.com/file/2019/11/WechatIMG2-9edb8e27.jpeg)


后面就是日常操作了，客户端请求，在我们需要的位置打断点。这里有一点需要说明的是，我们平时在debug的过程中要善用条件断点，不然在跟踪指定数据的过程经常会被无用的数据干扰，尤其是在循环里面。

#### 2.2 小技巧原理

说完操作，再说下原理，我们能远程debug的功劳，主要来源于这行配置，
```
agentlib:jdwp=transport=dt_socket,address=``21993``,server=y,suspend=n
```
这里配置的含义如下：

* 指定运行的被调试应用和调试者之间的通信协议，(ie: *transport=dt_socket*)
* 远程被调试应用开通的端口，(ie: address=1043)， 可定义其他端口，比如9999
* server=y 表示这个 JVM 即将被调试
* suspend=n 用来告知 JVM 立即执行，不要等待未来将要附着上/连上（attached）的调试者。如果设成 y, 则应用将暂停不运行，直到有调试者连接上

简单来说，其实就是我们配置的agentlib这个agent具有拦截JVM中运行的代码的能力，这样也就给了我们调试和观察代码在运行过程中参数的变化。详细的原理，在一篇博文中感觉博主讲的非常清晰，这里给大家一起分享下。

* 远程JVM调试怎么工作的？

一切源于被称作Agents的东西。
运行着各种编译过的.class文件的JVM，有一种特性，可以允许外部的库（Java或C++写的libraries）在运行时注入到JVM中。这些外部的库就称作Agents, 他们有能力修改运行中 .class 文件的内容。
这些Agents拥有的这些JVM的功能权限，是在JVM内运行的Java Code所无法获取的，他们能用来做一些有趣的事情，比如修改运行中的源码，性能分析等。像JRebel工具就是用了这些功能达到魔术般的效果。
传递一个Agent Lib给JVM, 通过添加 agentlib:libname[=options] 格式的启动参数即可办到。像上面的远程调试我们用的就是**-agentlib:jdwp=... **来引入jdwp这个Agent的。
jdwp是一个JVM特定的JDWP（Java Debug Wire Protocol）可选实现，用来定义调试者与运行JVM之间的通讯，它是通过JVM本地库的jdwp.so或者jdwp.dll支持实现的。

****简单来说，jdwp agent会建立运行应用的JVM和调试者（本地或者远程）之间的桥梁。既然他是一个Agent Library, 它就有能力拦截运行的代码。****
在JVM架构里，debugging功能在JVM本身的内部是找不到的，它是一种抽象到外部工具的方式（也称作调试者 debugger）。这些调试工具或者运行在JVM的本地或者在远程。这是一种解耦，模块化的架构。



